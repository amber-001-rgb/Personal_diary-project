assert = chai.assert;


describe('Login and Logout Page', () => {
  // Test for /signinServer endpoint
  describe('/POST signinServer', () => {
    it('it should sign in the user with correct credentials', (done) => {
      const credentials = {
        usernameEntered: 'testuser',
        passwordEntered: 'testpassword'
      };
      chai.request(app)
        .post('/signinServer')
        .send(credentials)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('signin0').equal('signedIn');
          res.body.should.have.property('dataEntries');
          done();
        });
    });

    it('it should return an error for wrong credentials', (done) => {
      const credentials = {
        usernameEntered: 'testuser',
        passwordEntered: 'wrongpassword'
      };
      chai.request(app)
        .post('/signinServer')
        .send(credentials)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('signin0').equal('wrongPassword');
          done();
        });
    });

    it('it should return an error for non-existent user', (done) => {
      const credentials = {
        usernameEntered: 'nonexistentuser',
        passwordEntered: 'password'
      };
      chai.request(app)
        .post('/signinServer')
        .send(credentials)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.property('signin0').equal('noUser');
          done();
        });
    });
  });

});
